# yolo sign detection > 2024-11-20 4:39pm
https://universe.roboflow.com/riya-p1xrc/yolo-sign-detection

Provided by a Roboflow user
License: CC BY 4.0

